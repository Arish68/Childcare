<?php

namespace App\Http\Controllers\ApiControllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\User\AddUserRequest;
use App\Http\Requests\User\UserLoginRequest;
use App\Models\Customer;
use App\Http\Resources\User\LoginResource;
use App\Http\Resources\SearchedTeachersCollection;

class UserController extends Controller
{
	
    public function addUser(AddUserRequest $request){

            $data=$request->all();
    	    if($request->hasFile('image')){
    	      $extension=$request->image->extension();
    	      $filename=time()."_.".$extension;
    	      $request->image->move(public_path('userImages'),$filename);
              $data['image']=$filename;
    	    }
    	    $result=Customer::create($data);
    	    if ($result) {   	        
    	        return response([
    	            'message'=>'Record Created Successfully.',
    	            'status' =>'success'
    	        ]);
    	    }
    	    return response([
    	            'message'=>'Record Not Created.',
    	            'status' =>'error'
    	        ]);
    	   } 

    public function userLogin(UserLoginRequest $request){

      //echo 'check'; exit;

    	$user=Customer::where('email',$request->email)
    	      ->where('password',$request->password)->first();

    	if (!empty($user)) {   			
    		  return new LoginResource($user);
    	}
              return response(['message' => 'Login Not Successfully','status' =>'error']);
    }

     public function profile($id){


         $user=Customer::find($id);

        if (!empty($user)) {

              return new LoginResource($user);
        }
              return response(['message' => 'Profile Not Found','status' =>'error']);
    }

    public function search(Request $request){

         $data=Customer::select('*')

                  ->when( !empty($request->gender), function($query) use ($request) {
                            return $query->where('gender', '=',$request->gender);
                        })
                  ->when( !empty($request->minrate) && !empty($request->maxrate), function($query) use($request) {

                         return $query->whereBetween('rate', [$request->minrate,$request->maxrate]);
                        })                                           
                        ->where('type',0)
                        ->get();
         if (!empty($data)) {               
              return SearchedTeachersCollection::collection($data);
        }
              return response(['message' => 'Record Not Found','status' =>'error']);               
    }



} 


