<?php

namespace App\Http\Controllers\ApiControllers\Meeting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Meeting\MeetingCommentRequest;
use App\Traits\ResponseTrait;
use App\Models\Comment;

class MeetingCommentsController extends Controller
{
    use ResponseTrait;

    public function postComment(MeetingCommentRequest $request){

    	    $data=$request->validated();	 
    	    $result=Comment::create($data);
	    	 if ($result) {
	    	 	return $this->reponseMessage('Comment Posted Successfully.','success');
	    	 }
    	     return $this->reponseMessage('Comment Not Posted.','error');               	
    	                
    	 
    }
}
