<?php

namespace App\Http\Controllers\ApiControllers\Rating;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Rating;
use App\Traits\ResponseTrait;
use App\Http\Resources\RatingCollection;
use DB;

class RatingController extends Controller
{
	 use ResponseTrait;

     public function rating(Request $request){
            
           // print_r($request->all()); exit;
            $check=Rating::where('customer_id',$request->customer_id)
          //  ->where('type',0)
            ->where('request_id',$request->request_id)->exists();
            if ($check) {
            	return $this->reponseMessage('Request Already Saved','error');
            }
            		$rating=Rating::create($request->all());
    		    	if ($rating) {
           	   
           	           return $this->reponseMessage('Request Saved','success');
                     }

           	          return $this->reponseMessage('Request Not Saved','error');
         	
        }

    public function getRating($request_id)
    {
      //echo 'just check'; exit;
      //echo $request_id; exit;
         $rating=Rating::from('ratings as r')
                       ->join('customers as c','c.id','=','r.customer_id')
                       ->join('applied_requests as ar','ar.request_id','=','r.request_id')
                       ->select('c.*','r.*')
                       ->where('r.request_id',$request_id)
                       ->where('c.type',0)
                      // ->where('ar.status', 'accepted')
                       ->get();
                      // DB::enableQueryLog();
                     //  dd(DB::getQueryLog()); exit;
        if ($rating->count() > 0) {

            return  RatingCollection::collection($rating);

        }
        return $this->reponseMessage('Request Not Found','error');
    }    
}
