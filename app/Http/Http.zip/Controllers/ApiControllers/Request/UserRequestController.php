<?php

namespace App\Http\Controllers\ApiControllers\Request;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Request\CreateRequest;
use App\Models\UserRequest;
use App\Models\Customer;
use App\Models\ApprovedRejectNotification;
use App\Models\Requestnotification;
use App\Traits\ResponseTrait;
use App\Http\Resources\UserRequestsResource;
use App\Http\Resources\RequestDetail;
use App\Http\Resources\ParentRequestsResourceCollection;
use App\Http\Resources\AppliedRequestCollection;
use App\Models\Appliedrequest;

class UserRequestController extends Controller
{
	 use ResponseTrait;

     public function createRequest(CreateRequest $request){

     	$data=$request->validated();
     	$result=UserRequest::create($data);
     	if ($result) {

          $teachers=Customer::where('type',0)->get(['id']);
          foreach ($teachers as $key => $value) {
            $re=new Requestnotification();
            $re->teacher_id=$value->id;
            $re->save();
          }
     		return $this->reponseMessage('Request created successfully','success');
     	}
     	   return $this->reponseMessage('Request not created','error');
     }

     public function apply(Request $request){
      
      $data=$this->validate($request,[

        'teacher_id' =>'required',
        'request_id' =>'required',
        

      ]);

      $check=Appliedrequest::where('teacher_id',$request->teacher_id)->where('request_id',$request->request_id)->exists();
     
    if ($check) {
      return $this->reponseMessage('Request alerady applied','error');
    }
      $result=Appliedrequest::create($data);
      if ($result) {

        return $this->reponseMessage('Request applied successfully','success');
      }
         return $this->reponseMessage('Request not applied','error');
     }

     public function changeStatus($id,$request_id,$parent_id,$status){


        $data=Appliedrequest::where('teacher_id',$id)->update([
          'parent_id'=>$parent_id,
          'status'=>$status,
        ]);

        if ($data) {

          $teacher_id=Appliedrequest::find($id);
          UserRequest::where('id',$request_id)->update([         
          'status'=>$status == 'accepted' ? 'active' : 'cancelled',
          'teacher_id'=>$teacher_id->teacher_id,
          ]);
          $teacher=Appliedrequest::find($id);
          $noti=new ApprovedRejectNotification();
          $noti->teacher_id=$teacher->teacher_id;
          $noti->message=$status=='accepted' ? 'Yours request approved' : 'Yours request rejected';

          $noti->save();

        }

        return $this->reponseMessage('Request accepted successfully','success');
     }

     public function appliedRequestList($id){
        
         $data=Customer::from('customers as c')
                ->join('applied_requests as ar','c.id','=','ar.teacher_id')
                ->whereNull('ar.status')
                ->where('ar.request_id',$id)
                ->get(['c.*','ar.request_id','ar.id','ar.price']);
        if ($data->isNotEmpty()) {      
           return AppliedRequestCollection::collection($data);
        }
           return $this->reponseMessage('Data not found','error');      
     }


      public function teacherRequestList(){

      $data=Customer::from('customers as c')
            ->join('user_requests as ur','c.id','=','ur.customer_id')
            ->leftjoin('applied_requests as ar','ar.request_id','=','ur.id')
            ->where('ur.status',null)
            ->get(['c.image','ur.*','ar.id as applied_request_id']);

      if ($data->isNotEmpty()) {      
        return ParentRequestsResourceCollection::collection($data);
      }
      return $this->reponseMessage('Data not found','error');
     }

     public function detail($id){

      $data=Customer::from('customers as c')
                ->join('user_requests as ur','c.id','=','ur.customer_id')
                ->where('ur.id',$id)->first(['c.image','ur.*']);

      if ($data) {  
           
        return new RequestDetail($data);
      }
      return $this->reponseMessage('Data not found','error');
     }

      public function sameCode1(){
          return Customer::from('customers as c')
                ->join('user_requests as ur','c.id','=','ur.customer_id')
                ->where('c.type',1);
     }

     public function userRequestList($id){
      //echo $id; exit;
     	$data=Customer::from('customers as c')
            ->join('user_requests as ur','c.id','=','ur.customer_id')
            ->where('ur.customer_id',$id)->get(['c.*','ur.*']);

     	if ($data->isNotEmpty()) {   		
     		return UserRequestsResource::collection($data);
     	}
     	return $this->reponseMessage('Data not found','error');
     }

     public function sameCode($id){
          return Customer::from('customers as c')
                ->join('user_requests as ur','c.id','=','ur.customer_id')
                ->where('ur.customer_id',$id);
     }

     public function requestList($id,$status){

           $data=Customer::from('customers as c')
                ->join('user_requests as ur','c.id','=','ur.customer_id')
                
                ->where('ur.customer_id',$id)
                
                ->where('ur.status',$status=='null' ? null : $status)
                ->get(['c.*','ur.*']);

          if ($data->isNotEmpty()) {         
               return UserRequestsResource::collection($data);
          }

          return $this->reponseMessage('Data not found','error');
     }

     public function listing($id,$status){

          $data=Customer::from('customers as c')
                ->join('user_requests as ur','c.id','=','ur.customer_id')
                ->where('ur.teacher_id',$id)             
                ->where('ur.status',$status=='null' ? null : $status)
                ->get(['c.image','c.firstname','c.lastname','c.gender','ur.*']);

          if ($data->isNotEmpty()) {         
               return UserRequestsResource::collection($data);
          }

          return $this->reponseMessage('Data not found','error');
     }

      public function moveRequest($id,$status){

          $data=UserRequest::where('id',$id)->update([
              
              'status'=>$status,
          ]);

          if ($data) {         
               
               return $this->reponseMessage('Done','success');
          }

          return $this->reponseMessage('Data not found','error');
     }


}
