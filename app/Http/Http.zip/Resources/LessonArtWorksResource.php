<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\jsonResource;
use App\Models\LessonArtWorks;

class LessonArtWorksResource extends jsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [

            'id' => $this->art_id,
            'Lesson id' => $this->lesson_id,
            'Teacher id' => $this->teacher_id,
            'Art Title' => $this->art_title,
            //'Art Image' => $this->art_image,
            //'name' => is_null($this->admin_name) ? $this->firstname.' '.$this->lastname : $this->admin_name,
            //'type' => is_null($this->admin_name) ? 'User' : 'Admin',
            'Art Image' => is_null($this->art_image) ? '0' : asset('public/lessonImages/artworks/'.$this->art_image),
           // 'comment' => $this->message,
           'Date' => createdAtDateFormate($this->art_created_at),
           'Art Detail' => route('lesson-artwork-detail',$this->art_id)
        ];
    }
}
