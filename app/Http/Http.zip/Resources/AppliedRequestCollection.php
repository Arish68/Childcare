<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AppliedRequestCollection extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [

                  'id'      => $this->id,

                  'request_id' => $this->request_id,

                   'firstname' => $this->firstname,

                    'lastname' => $this->lastname,

                    'email' =>  $this->email,

                    'password' => $this->password,

                    'phone_no' => $this->phone_no,

                    'gender' => $this->gender,

                    'address' => $this->address,

                    'type' => $this->type == 1 ? 'Parent' : 'Service Provider',

                    'price' => $this->price,


            'user_image'  => asset('public/userImages/'.$this->image),
        ];
    }
}
