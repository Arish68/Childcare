<?php

namespace App\Http\Resources\User;

use Illuminate\Http\Resources\Json\JsonResource;

class LoginResource extends JsonResource
{
    
    public function toArray($request)
    {
        return [

                    'id' =>$this->id,

                    'firstname' => $this->firstname,

                    'lastname' => $this->lastname,

                    'email' =>  $this->email,

                    'password' => $this->password,

                    'phone_no' => $this->phone_no,

                    'address' => $this->address,

                    'gender' => $this->gender,

                    'type' => $this->type == 1 ? 'Parent' : 'Service Provider',

                    'userimage'=> asset('public/userImages/'.$this->image),

                    'bio' => $this->bio,

                    'education' => $this->education,

                    'work_history' =>  $this->work_history,

                    'skills' => $this->skills,

                    'rate' => $this->rate,
                   

                    
        ];
    }
}




