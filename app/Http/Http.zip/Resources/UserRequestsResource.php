<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\Appliedrequest;

class UserRequestsResource extends JsonResource
{
   
    public function toArray($request)
    {
       $price= Appliedrequest::getPrice($this->customer_id);
        return [

            'id'      => $this->id,
            'user_id' => $this->customer_id,
            'firstname' => $this->firstname,
            'lastname' => $this->lastname,
            'service' => $this->service,
            'gender' => $this->gender,
            'address' => $this->address,
            'type' => $this->type == 1 ? 'Parent' : 'Service Provider',
            'from'    => dateFormate($this->from),
            'to'      => dateFormate($this->to),
            'status'  => is_null($this->status) ? 'new' : $this->status,
            'created_at'  => createdAtDateFormate($this->created_at),
            'user_image'  => asset('public/userImages/'.$this->image)

        ];
    }
}
