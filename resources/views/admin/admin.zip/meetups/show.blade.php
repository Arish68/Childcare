@extends('admin.layouts.app')

   @section('main-content')
 
   <main class="main-content">
     <div class="row">
     	<div class="col-lg-3">
     	</div>

     	<div class="col-lg-5">
			 
			
	       <div class="card">

	                    <div class="card-body">
	                        <h5 class="card-title"><strong>Show Meetup</strong></h5>
	                            <div class="form-group">

	                                <label>Title</label>
	                                <input type="text" class="form-control"
								      readonly value="{{$meetup->title}}">
								 </div>

								 <div class="form-group">

	                                <label>Meeting Date</label>
	                                <input type="date" class="form-control"
								      readonly value="{{$meetup->meeting_date}}">
								 </div>

								 <div class="form-group">

	                                <label>Meeting Time</label>
	                                <input type="time" class="form-control"
								      readonly value="{{$meetup->meeting_time}}">
								 </div>

								 <div class="form-group">

	                                <label>Address</label>
	                                <input type="text" class="form-control"
								     readonly value="{{$meetup->address}}">
								 </div>

								<div class="form-group">

	                                <label>Description</label>
	                                
								     <textarea rows="5" name ="description" class="form-control" readonly>{{$meetup->description}}</textarea>

								 </div>

								 <img id="blah" src="@if(empty($meetup->image)){{asset('public/admin-assets/admin-panal-images/default.jpg')}} @else {{asset('public/meetupImages/'.$meetup->image)}}@endif" alt="Course image" 
                        style="width:100%;height: 200px;" class="thumbnail img-responsive" />
                        <br><br>

								

	        <a href="{{route('meetup-management.meetups.index')}}" class="btn btn-block" id="btncolor">Back</a>
	                        
	                    </div>
	        </div>
       </div>


     </div> 

    </main> 
	
   @endsection