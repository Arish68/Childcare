


<!-- begin::global scripts -->
<script src="{{asset('public/admin-assets/assets/vendors/bundle.js')}}"></script>
<!-- end::global scripts -->


<!-- begin::custom scripts -->
<script src="{{asset('public/admin-assets/assets/js/custom.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/js/borderless.min.js')}}"></script>
<!-- end::custom scripts -->

<script src="{{asset('public/admin-assets/assets/vendors/datepicker/daterangepicker.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/js/examples/dashboard.js')}}"></script>




<!-- begin::select2 -->
<script src="{{asset('public/admin-assets/assets/vendors/select2/js/select2.min.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/js/examples/select2.js')}}"></script>
<!-- end::select2 -->

    <!-- begin::lightbox -->
	<script src="{{asset('public/admin-assets/assets/vendors/lightbox/jquery.magnific-popup.min.js')}}"></script>
	<script src="{{asset('public/admin-assets/assets/js/examples/lightbox.js')}}"></script>
	<!-- end::lightbox -->

<!-- begin::dataTable -->
<script src="{{asset('public/admin-assets/assets/vendors/dataTable/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/vendors/dataTable/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/vendors/dataTable/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/js/examples/datatable.js')}}"></script>
<!-- end::dataTable -->

<script src="{{asset('public/admin-assets/assets/vendors/tagsinput/bootstrap-tagsinput.js')}}"></script>
<script src="{{asset('public/admin-assets/assets/js/examples/tagsinput.js')}}"></script>


	
<!-- image selector -->
<script type="text/javascript">
 function readURL(input) {
	  if (input.files && input.files[0]) {
	    var reader = new FileReader();

	    reader.onload = function (e) {
	      $('#blah')
	      .attr('src', e.target.result);
	    };

	    reader.readAsDataURL(input.files[0]);
	  }
}
</script>


<!-- image selector -->