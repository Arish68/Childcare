<!-- begin::sidebar -->
<div class="sidebar" >
    
</div>
<!-- end::sidebar -->

<!-- begin::side menu -->
<div class="side-menu" >
    <div class='side-menu-body'>
        <ul>
            <li class="side-menu-divider m-t-0 ">@if(Auth::check()) {{ Auth::user()->name}} @endif</li>
            <li class="">
                <a href="{{route('/admin')}}">
                    <i class="icon fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            
            </li>


     


            <li class="">
                   <a href="{{route('meetup-management.meetups.add')}}">
                       <i class="icon fa fa-link"></i>
                       <span>Add Meetup</span>
                   </a>
            </li> 

             <li class="">
                   <a href="{{route('meetup-management.meetups.index')}}">
                       <i class="icon fa fa-link"></i>
                       <span>All Meetups</span>
                   </a>
            </li> 

 
            
        </ul>

        <ul>
         
            <li class="">
                
                    <i class="icon fa fa-book"></i>
                    <span style="font-size: 15px;"><b>Lessons</b></span>
             
            
            </li>


     


            <li class="">
                   <a href="{{route('add')}}">
                       <i class="icon fa fa-link"></i>
                       <span>Add Lesson</span>
                   </a>
            </li> 

             <li class="">
                   <a href="{{route('all')}}">
                       <i class="icon fa fa-link"></i>
                       <span>All Lessons</span>
                   </a>
            </li> 

               <li class="">
                   <a href="{{route('art-works')}}">
                       <i class="icon fa fa-link"></i>
                       <span>Art & Works</span>
                   </a>
            </li> 

 
            
        </ul>
              <ul>
         
            <li class="">
                
                    <i class="icon fa fa-list-alt"></i>
                    <span style="font-size: 15px;"><b>Lessons Category</b></span>
             
            
            </li>


     


            <li class="">
                   <a href="{{route('add-category')}}">
                       <i class="icon fa fa-link"></i>
                       <span>Add Category</span>
                   </a>
            </li> 

             <li class="">
                   <a href="{{route('all-categories')}}">
                       <i class="icon fa fa-link"></i>
                       <span>All Categories</span>
                   </a>
            </li> 

 
            
        </ul>
       
       
    </div>
</div>
<!-- end::side menu -->