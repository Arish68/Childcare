    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- begin::global styles -->
    <link rel="stylesheet" href="{{asset('public/admin-assets/assets/vendors/bundle.css')}}" type="text/css">
    <!-- end::global styles -->



        <!-- begin::dataTable -->
    <link rel="stylesheet" href="{{asset('public/admin-assets/assets/vendors/dataTable/responsive.bootstrap.min.css')}}" type="text/css">
    <!-- end::dataTable -->

        <!-- begin::global styles -->
        <link rel="stylesheet" href="{{asset('public/admin-assets/assets/vendors/bundle.css')}}" type="text/css">
        <!-- end::global styles -->
    
 <!-- begin::select2 -->
 <link rel="stylesheet" href="{{asset('public/admin-assets/assets/vendors/select2/css/select2.min.css')}}" type="text/css">
 <!-- end::select2 -->

  
    
    <link rel="stylesheet" href="{{asset('public/admin-assets/my-css-style.css')}}" type="text/css">
    

    <!-- begin::custom styles -->
    <link rel="stylesheet" href="{{asset('public/admin-assets/assets/css/app.min.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('public/admin-assets/assets/css/custom.css')}}" type="text/css">
    <!-- end::custom styles -->

 



    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    