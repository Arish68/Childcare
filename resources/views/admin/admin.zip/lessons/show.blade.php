@extends('admin.layouts.app')

   @section('main-content')
 
   <main class="main-content">
     <div class="row">
     	<div class="col-lg-3">
     	</div>

     	<div class="col-lg-5">

@if($lessons)			 
@foreach($lessons as $lesson)	
@endforeach		
	       <div class="card">

	                    <div class="card-body">
	                        <h5 class="card-title"><strong>Show/Edit Lesson</strong></h5>
	                        <form action="{{route('update',$lesson->id)}}" method="post" enctype="multipart/form-data">
								{{csrf_field()}}
								{{method_field('PUT')}}


	                        <div class="form-group">


	                               <label>Cetogory</label>
	                               <select name="category_id" class="form-control">
	                               	<option value="{{$lesson->category_id}}">{{$lesson->cat_title}}</option>
	                           
	                               </select>
								 </div>
	                            <div class="form-group">

	                                <label>Title</label>
	                                <input name="title" type="text" class="form-control"
								       value="{{$lesson->title}}">
								 </div>

								 <div class="form-group">

	                                <label>Purpose</label>
	                                
								     <textarea rows="5" name ="purpose" required placeholder="Purpose" class="form-control" >{{$lesson->purpose}}</textarea>

								 </div>

									<div class="form-group">

	                                <label>Supplies 1</label>
	                                
								     <textarea rows="5" name ="supplies_1" required class="form-control" >{{$lesson->supplies_1}}</textarea>

								 </div>

								<div class="form-group">

	                                <label>Supplies 2</label>
	                                
								     <textarea rows="5" name ="supplies_2" required  class="form-control" >{{$lesson->supplies_2}}</textarea>

								 </div>

						<img id="blah" src="@if(empty($lesson->image)){{asset('public/admin-assets/admin-panal-images/default.jpg')}} @else {{asset('public/lessonImages/'.$lesson->image)}}@endif" alt="Lesson image" 
                        style="width:100%;height: 200px;" class="thumbnail img-responsive" />
                        <br><br>
                         <div class="input-group" id="removeFileOption">
                        
                          <div id="" class="custom-file">
                            <input type="file" class="custom-file-input" id="inputGroupFile01"
						  aria-describedby="inputGroupFileAddon01"  name="image" onchange="readURL(this);getImagVal();" value="{{old('image')}}">
						  <label class="custom-file-label" for="inputGroupFile01" >Choose file</label>
                          </div>


								

					

				

								
             <button type="submit" class="btn  btn-block" id="btncolor">Update</button>
         </form>
	                
	        <a href="{{route('all')}}" class="btn btn-block" id="btncolor">Back</a>
	                        
	                    </div>
	        </div>

	        @else

	        <p>No Record!</p>

	        @endif
       </div>


     </div> 

    </main> 
	
   @endsection